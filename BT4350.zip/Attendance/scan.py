import cv2
from pyzbar.pyzbar import decode
import datetime

def mark_attendance(code, filename='attendance.txt'):
    with open(filename, 'a') as file:
        current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        file.write(f'{code} - {current_time}\n')

def scan_codes():
    cap = cv2.VideoCapture(0)

    while True:
        _, frame = cap.read()
        codes = decode(frame)

        for code in codes:
            code_data = code.data.decode('utf-8')
            mark_attendance(code_data)
            print(f'Attendance marked for: {code_data}')

        cv2.imshow('Attendance System', frame)

        if cv2.waitKey(1) & 0xFF == 27:  # Press 'Esc' to exit
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    scan_codes()