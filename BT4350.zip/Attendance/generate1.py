import csv
import os
from barcode import Code128
from barcode.writer import ImageWriter

def generate_barcode(data, output_folder):
    # Generate a CODE128 barcode
    code = Code128(data, writer=ImageWriter())
    code.save(os.path.join(output_folder, f"{data}.png"))

def create_barcodes_from_csv(input_csv, output_folder):
    # Ensure the output folder exists
    os.makedirs(output_folder, exist_ok=True)
    
    with open(input_csv, 'r') as csv_file:
        csv_reader = csv.reader(csv_file)
        next(csv_reader)  # Skip the header
        for row in csv_reader:
            name, rollno, admission_no = row
            data = f"{rollno}_{admission_no}"
            generate_barcode(data, output_folder)

create_barcodes_from_csv("student_detail.csv", "barcodes_pic")