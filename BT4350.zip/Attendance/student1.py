import csv

# Define the data
data = [
    ["Name", "Rollno", "Admission No"],
    ["Anirudh", 2, "A123"],
    ["Ayush", 3, "A124"],
    ["Neha", 4, "A125"],
    ["Nisha", 5, "A126"],
    ["Priyal", 6, "A127"],
    ["Raghav", 7, "A128"],
    ["Sakshi", 8, "A129"],  
]

# Specify the CSV file path
csv_file_path = "student_detail.csv"

# Write data to the CSV file
with open(csv_file_path, mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(data)

print("CSV file created:", csv_file_path)